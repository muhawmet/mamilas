# MAMILAS Kling-Safe 5-6 Beat Patch

Date: 2026-06-01

This patch updates MAMILAS for the user's real creative-director workflow:

1. Source can be a ready voice-over script, client brief, or rough idea.
2. Nano Banana 2 / Gemini Image creates approved start frames first.
3. Kling 3.0 animates those start frames as short image-to-video motion beats.
4. ElevenLabs voice-over and Suno music are produced separately.
5. Premiere is the final edit and client delivery layer.

## Kling 3.0 Timing Rule

Official Kling 3.0 material supports longer generation and Custom Multi-Shot, but this package no longer treats 15 seconds as the safe default for one start-frame image-to-video shot.

Default single start-frame unit:

- Target: 5-6 seconds.
- 6s+: risk warning.
- 8s+: split or Custom Multi-Shot.
- Long VO should be covered by multiple visual beats, not by stretching one prompt.

## Character Policy

Aras + Defne is one education preset, not the whole system.

For the Aras + Defne preset:

- Characters are used as anchors only when useful.
- The world explains by default.
- A rough budget is 25% character presence / 75% world-explains.
- Speaker names in VO do not force character visibility.

For other projects, no Aras/Defne logic is applied unless the user chooses that preset or supplies matching references.

## Site / Agent Changes

- Lossless VO ingest now splits toward 5-6s visual beats.
- Scene cards show 6s+ / 8s+ risk states.
- Motion prompts are pure motion only: one camera/action idea, one physical event, stable final hold.
- Final Brief includes Nano Banana -> Kling -> ElevenLabs -> Suno -> Premiere workflow.
- GPT, Claude and shared knowledge files were updated to remove the old 15s default.
