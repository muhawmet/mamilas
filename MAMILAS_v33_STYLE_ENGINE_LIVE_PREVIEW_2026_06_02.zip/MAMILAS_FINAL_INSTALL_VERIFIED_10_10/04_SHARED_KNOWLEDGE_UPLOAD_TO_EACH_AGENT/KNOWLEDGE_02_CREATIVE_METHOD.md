# MAMILAS Knowledge 02 — Creative Method & Banned Vocabulary

## GENERATE THE NON-OBVIOUS (run before writing any prompt)
Most prompts die at the first obvious image. Push past it with at least one move, motivated by the idea:
- **VANTAGE** — refuse the default eye-level master. Where is the camera nobody expects but that reveals the idea: inside the object, beneath it, from what is being acted upon, too close, too far?
- **INVERSION** — show the thing through its consequence, not itself. Hide the hero until it is earned. Reveal by absence.
- **LITERAL METAPHOR** — take the abstract benefit and make it one physical object or event you can actually film.
- **MICRO-TRUTH** — the one small real human gesture that carries more feeling than any grand statement.
- **WITHHOLD** — decide what you do not show, and how long you make them wait. The slow burn is a choice.

**Taste rule:** surprising but inevitable. Bold but unmotivated = noise, kill it. Safe enough that anyone could have made it = push again.

## BANNED VOCABULARY (the "basic AI" smell — never output)
cinematic, dynamic, beautiful, stunning, epic, vibrant, dramatic lighting, glowing particles,
magical, 4K, ultra-detailed, masterpiece, immersive, breathtaking, mesmerizing, captivating, otherworldly.

Each banned word is a decision skipped. Replace it with the concrete thing it was hiding:
- dramatic lighting -> the source, its angle, its hardness, and what it carves
- glowing particles -> what they are, why they are lit, how they move
- cinematic -> the lens, the framing, the one move
- dynamic -> the one force and the one thing it moves

## ELEVATION MANDATE
Good idea -> perfect it. Weak idea -> rebuild it (same scene meaning, same visual locks, same source text,
same locks) and flag in one line: `ELEVATED: <what you upgraded and why>`. Never downgrade identity,
source integrity, text/logo, or the path.


FINAL INSTALL NOTE: Automatic tag creation is an Image-agent concern only. Non-image agents should use normal descriptions and should not create visual tags. Animation Education is a polished 3D Pixar-quality world shell with clay/paper/wood lesson dioramas inside it. If no post typography stage exists, use integrated physical typography only when clarity needs it.
