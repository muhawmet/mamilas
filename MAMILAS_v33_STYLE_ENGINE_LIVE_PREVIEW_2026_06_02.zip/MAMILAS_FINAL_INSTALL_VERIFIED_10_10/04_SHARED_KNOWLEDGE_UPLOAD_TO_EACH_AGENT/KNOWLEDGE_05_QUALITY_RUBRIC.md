# MAMILAS Knowledge 05 — Quality Rubric (the 95-100 standard)

Every block is scored 0-100 and must reach 97+ before emit. Below 97 = fix the failing field and re-score. Below 95 = hard fail; rebuild the block, do not polish it.

## 9.7 OUTPUT FLOOR
A maker output may not be emitted until it clears a 9.7/10 internal floor: path grammar visible, source preserved, one dominant idea, no decorative character use, no semantic contamination, no empty placeholder, and a concrete physical/material cause for every visual or motion effect. If a block feels merely good, rebuild the weak field before output.

## IMAGE /100
IDEA 12 | FRAME+LENS named & justified 12 | LIGHT 18 (source 5 + direction 4 + hardness 3 + temperature 3 + carves 3) | MATERIAL exact-surface behaviour 15 | DEPTH foreground+background 10 | SEED primed element + stable start 10 | LOCKS 13 (visual locks 4 + text/logo state 5 + forbidden 4) | CLEAN zero banned words 10.

## MOTION /100
CAMERA one motivated move first 15 | ACTION 18 (cause->effect->settle chain 9 + named physics 9) | PURE-MOTION no re-description / anti-morph 18 | REVEAL withheld beat 8 | RESPONSE surface+light answer the move 12 | NEGATIVES 14 (text/logo 7 + face/product/visual lock 7) | TAIL stable final frame 10 | CLEAN no banned words / no "dynamic camera" 5.

## MOTION EVENT GATE (path-scoped gate)
A motion prompt with camera movement but NO physical event (the lesson/hero object does not visibly change) is capped below 95 and fails. Every motion needs one primary event. A deliberate static / POV / child-eye / inside-object camera is valid and fully credited.

## SUNO /100
JOB 12 | INSTRUMENTS named real instruments + playing style 20 | TEMPO bpm + groove 12 | STRUCTURE intro/build/peak/resolve mapped to scenes 16 | VO-SAFE midrange pocket + duck + no vocals unless asked 16 | SPACE reverb/room 8 | EXCLUDE list 8 | CLEAN no mood-filler 8.

## IDEA /100
READ infer objective+audience+feeling 15 | INSIGHT a human truth not the topic 20 | 3 DISTINCT ROUTES each logline+feeling+signature shot 25 | RECOMMENDATION + defense 12 | SCENE ARCHITECTURE beat-mapped to 5-6s visual beats 18 | HANDOFF + locks 10.

## BANNED VOCABULARY (auto-fail)
cinematic, dynamic, beautiful, stunning, epic, vibrant, dramatic lighting, glowing particles, magical, 4K,
ultra-detailed, masterpiece, immersive, breathtaking, mesmerizing, captivating, otherworldly; plus
"dynamic camera" and mood-filler ("emotional uplifting cinematic background music").


FINAL INSTALL NOTE: Automatic tag creation is an Image-agent concern only. Non-image agents should use normal descriptions and should not create visual tags. Animation Education is a polished 3D Pixar-quality world shell with clay/paper/wood lesson dioramas inside it. If no post typography stage exists, use integrated physical typography only when clarity needs it.
