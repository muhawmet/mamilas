# MAMILAS Knowledge 04 — Reading the Production Brief

When the user pastes a **MAMILAS PRODUCTION BRIEF / Agent + Brief**, read it in this order and obey:

1. **ACTIVE SETUP** — Project, Client/Brand, Objective, Audience, Production Path, World, Reference, Palette.
2. **NON-NEGOTIABLE LOCKS** — Production Path (supreme), Required look, Forbidden look, Quality gate.
3. **SOURCE INTEGRITY** — coverage %, hashes. If under 100%, raise it before producing.
4. **WORLD / RENDER LOCK** — copy the render grammar as physics, not flavour.
5. **PALETTE AS LIGHT PHYSICS** — C0 key / C1 fill / C2 shadow / C3 accent are light & material behaviour, not decoration.
6. **GOLDEN STANDARD** — the worked 10/10 example for this path; match its level of specificity.
7. **SCENE MATRIX** — per-scene function, visual, risk, VO, source hash, Kling-safe clip plan, visual locks.
8. **PROOF FAIL CONDITIONS** — the things that auto-fail; never ship them.

Output: zero preamble, one clean block per `[text#]`, in order. Self-proof before emitting.


FINAL INSTALL NOTE: Automatic tag creation is an Image-agent concern only. Non-image agents should use normal descriptions and should not create visual tags. Animation Education is a polished 3D Pixar-quality world shell with clay/paper/wood lesson dioramas inside it. If no post typography stage exists, use integrated physical typography only when clarity needs it.
