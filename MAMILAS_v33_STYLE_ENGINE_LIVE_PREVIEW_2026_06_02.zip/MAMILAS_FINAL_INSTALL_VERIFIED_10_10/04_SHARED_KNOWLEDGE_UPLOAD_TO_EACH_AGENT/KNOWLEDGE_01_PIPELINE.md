# MAMILAS Knowledge 01 — Production Pipeline

The MAMILAS pipeline is three stages, in order. Each agent owns one stage; the output of one is the input of the next.

1. IMAGE — **Nano Banana 2 / Gemini 3.1 Flash Image**: produces the start frame. The still decides identity, world, light and material. Everything downstream inherits it. Nano Banana Pro / Gemini 3 Pro Image is the premium option for dense text, product fidelity or complex compositions.
2. MOTION — **Kling 3.0 / Kling 3.0 Omni (image-to-video)**: animates the approved start frame. Longer and multi-shot workflows exist, but default single start-frame production uses short 5-6s beats; start/end-frame compatibility and element reference help stability.
3. VOICE — **ElevenLabs**: produces routed VO, pacing and pronunciation-safe retakes.
4. MUSIC — **Suno v5.5 (Custom Mode)**: scores the cut, narration-safe.
5. EDIT — **Premiere**: receives scene order, target duration, VO, music cue, transition and final-hold notes.

## THE KLING 3.0 ANCHOR LAW (most important technical rule)
Kling 3.0 treats the start frame as a 3D anchor. If a motion prompt RE-DESCRIBES the subject's
identity, the environment, or the lighting, Kling re-renders the anchor and the result MORPHS
(faces drift, logos warp, products change shape). Therefore the Motion Director writes PURE MOTION
and physical reaction ONLY — never re-states what the image already fixed. Lock text, logo, face
geometry, product shape and visual lock identity as explicit negatives.

## KLING-SAFE SHORT BEATS
Each motion unit targets one short 5-6s visual beat. 6s+ is risk; 8s+ should be split
or treated as Custom Multi-Shot. Main action must settle into a stable final frame;
never stretch one start frame just to cover long VO.


FINAL INSTALL NOTE: Automatic tag creation is an Image-agent concern only. Non-image agents should use normal descriptions and should not create visual tags. Animation Education is a polished 3D Pixar-quality world shell with clay/paper/wood lesson dioramas inside it. If no post typography stage exists, use integrated physical typography only when clarity needs it.
