# MAMILAS Knowledge 06 — Nano Banana 2 & Kling 3.0 native prompting

The agents THINK in the rubric but EMIT prompts in each model's native language. The output is the
paste-ready prompt only — never the worksheet, never the labels, never the self-score.

## NANO BANANA 2 (Gemini 3.1 Flash Image)
- Builds ONE image from a described SCENE in natural language; follows instructions; renders legible text.
- NOT a tag model. Avoid semicolon spec-dumps and meta-labels (IDEA:/LIGHT:/SEED:/SELF-SCORE:).
- Identity = attached visual lock REFERENCE images. Describe the NEW scene/pose/light; do NOT re-describe a known face.
- Write motivated light as prose (source, direction, quality, temperature, what it carves). Put on-screen text in "quotes".

WORKSHEET (internal thinking — do NOT paste):
  FRAME+LENS: 85mm — ...; LIGHT: key = soft 5200K window from camera-left ...; SEED: ...; SELF-SCORE: 97/100
PASTE-READY (what the user actually pastes):
  "Medium close-up of a confident founder, late 30s, on an 85mm lens. She sits right of frame, a
  half-second before she speaks. Soft window light from camera-left at 45 degrees, ~5200K, wraps her
  face and carves the cheekbone; a faint warm bounce lifts the shadow side. Real skin — visible pores,
  no retouching; matte wool blazer. Office behind falls into soft out-of-focus depth. A clean
  lower-third reads "ELIF KAYA - CEO" in legible type. Avoid plastic skin, cartoon, CGI gloss."
WHY IT WINS: coherent scene prose (not a token bag), instruction-followable legible text, identity via
reference image, motivated light kept but phrased naturally, no meta-noise to render as text.

## KLING 3.0 (image-to-video)
- The start frame is a 3D ANCHOR. Re-describing identity/world/light makes it RE-RENDER and MORPH.
- A short clip fractures on many simultaneous events. Use ONE dominant motion. Camera move should agree
  with the subject's motion. Put freezes in the NEGATIVE-PROMPT field, not inline.

WORKSHEET (internal): CAMERA:/ACTION: gun->drive->launch->arm swing->foot strike->settle + grit + vest + sweat + SELF-SCORE
  -> too many events; high morph/mush risk.
PASTE-READY:
  Motion: "The sprinter drives out of the blocks into the first stride, explosive forward power, body
  rising slightly; camera holds a steady low tracking move alongside. Track grit kicks up behind."
  Negative prompt: "morphing, warping text, changing face, changing logo, extra limbs, flicker"
WHY IT WINS: one dominant motion stays coherent over the clip; no re-description (anti-morph); camera
agrees with travel; freezes go in the negative field; no editorial notes for Kling to choke on.

## SUNO v5.5 (Custom Mode)
PASTE-READY style line + structure + exclude; name real instruments + bpm + space; keep a VO midrange pocket.
Never paste "EMOTIONAL JOB" or a self-score.


FINAL INSTALL NOTE: Automatic tag creation is an Image-agent concern only. Non-image agents should use normal descriptions and should not create visual tags. Animation Education is a polished 3D Pixar-quality world shell with clay/paper/wood lesson dioramas inside it. If no post typography stage exists, use integrated physical typography only when clarity needs it.
