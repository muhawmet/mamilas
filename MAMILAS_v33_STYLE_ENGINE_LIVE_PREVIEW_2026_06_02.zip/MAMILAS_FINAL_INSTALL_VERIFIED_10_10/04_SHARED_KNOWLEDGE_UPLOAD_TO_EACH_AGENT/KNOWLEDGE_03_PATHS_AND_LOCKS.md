# MAMILAS Knowledge 03 — Production Paths & Locks

## PRODUCTION PATH IS SUPREME
Every job runs on one Production Path (set on the site, carried in the brief). The path decides the
Required look and the Forbidden look. If any prompt contradicts the path, it FAILS.

Common paths:
- **ANIMATION / EDUCATION** (e.g. Aras + Defne) — tactile 3D world material, dominant lesson-object, motion hook, character/lip safety. Forbidden: generic real-corporate defaults, stock-ad language, flat slides.
- **STYLIZED PREMIUM** — Arcane / Spider-Verse / anime / painterly / graphic, IP-SAFE. Use texture, value, light, camera, staging only. Forbidden: copied characters, logos, costumes, exact shots, named powers.
- **ULTRA REAL COMMERCIAL** — premium real advertising, brand desire, surface realism, studio/practical light. Forbidden: Pixar, 3D animated, clay, diorama, toy-world, cartoon, generic CGI sheen.
- **PRODUCT HERO** — product as hero object, geometry/material/reflection fidelity, brand role.

## SOURCE INTEGRITY LAW
Every `[text#]` scene keeps its source hash, character range and Kling-safe beat adaptation. Coverage must be
100%. If a character/scene is lost, Proof FAILS before production.

## @TAG POLICY
`Aras Defne logo reference location reference style reference` and any custom `visual lock` are VISUAL AUTHORITIES. Never rename,
replace, redesign or reinterpret a tagged asset.

## TEXT / LOGO POLICY
Text and logos are frozen and must stay legible. In motion they NEVER deform — move only light,
camera and reflection across them, never the glyphs/marks themselves.


FINAL INSTALL NOTE: Automatic tag creation is an Image-agent concern only. Non-image agents should use normal descriptions and should not create visual tags. Animation Education is a polished 3D Pixar-quality world shell with clay/paper/wood lesson dioramas inside it. If no post typography stage exists, use integrated physical typography only when clarity needs it.
