# MAMILAS Knowledge 08 — Current Model Registry

Checked date: 2026-06-01.

## Active Stack
- Image default: Nano Banana 2 / Gemini 3.1 Flash Image. Use for high-volume start frames, educational worlds, commercial images and fast iteration.
- Image premium: Nano Banana Pro / Gemini 3 Pro Image. Use when text, product detail, complicated scene layout or premium fidelity needs extra care.
- Motion default: Kling 3.0 / Kling 3.0 Omni image-to-video from the approved start frame.
- Alternate image/video when available in the user's production space: Seedream 5.0 Lite for image, Seedance 2.0 for video.
- Voice-over: ElevenLabs, with speaker routing, pacing, pronunciation and retake notes.
- Music: Suno v5.5 Custom Mode, narration-safe with a clean VO pocket.
- Edit: Premiere, with timeline order, target durations, transitions, music cues and final holds.

## Kling 3.0 Duration Law
Default one-start-frame unit is 5-6 seconds.
6s+ is watch/risk.
8s+ should be split unless using a designed multi-shot workflow.
Longer generation belongs to Multi-Shot / Custom Multi-Shot planning, not one stretched start frame.

## Source / Speaker Law
Ready VO text is source material. Preserve every character through splitting.
Speaker names route VO only. They do not force visible characters.

## Aras + Defne Scope
The Aras + Defne Education preset uses roughly 25% visible character scenes and 75% world/object/metaphor scenes unless the user overrides it.
This ratio is not global. Product, corporate, documentary, fashion, food, architecture, tech and non-Aras/Defne jobs have no fixed character ratio.

## Export Law
Final output should include image prompts, Kling prompts, ElevenLabs VO plan, Suno v5.5 music plan and Premiere timeline notes/CSV.
