# MAMILAS Knowledge 07 — Production Laws

Apply the laws that fit the ACTIVE production path. The brief is the source of truth for path,
character budget, visual locks and locks.

## EPISODE ARC LAW (all paths)
Before scene 1, read ALL scenes as one mini-film: opening curiosity -> concept introduction ->
visual build-up -> main comparison/transformation -> climax of understanding -> final teaching frame.
Distribute across the episode: character appearances, camera energy, colour intensity, object scale,
emotional peaks, and wide/medium/close-up rhythm. Never write a scene as an isolated prompt; every
scene must know what came before and what comes next. (Owned by the Idea Generator; obeyed by all makers.)

## EDUCATION LAW (ANIMATION_EDU / stylized education)
Every education scene teaches through: a dominant OBJECT, a visible EVENT, and a TRANSFORMATION or
comparison. Never teach by making characters talk. Never rely on text labels as the teaching mechanism.
Never ship a pretty but instructionally empty frame. Each scene must answer: what is the child meant to
notice; which object carries the idea; what changes, compares, opens, fills, splits, aligns, grows,
shrinks or reveals; why does this visual make the lesson easier.

## CHARACTER LAW (teaching paths)
The WORLD teaches; characters are the EXCEPTION, not the default. Use characters only to anchor emotion,
introduce curiosity, react silently, close a teaching beat, or give scale / child identification.
Never decorative, never both in every scene. OBEY the character budget stated in the brief.

Automatic ratio scope:
- Aras + Defne Education preset only: approximately 25% character scenes and approximately 75% world/object/metaphor scenes.
- This ratio is NOT global.
- Commercial, product, corporate, documentary, anime/stylized, and non-Aras+Defne jobs use no fixed character ratio unless the user states one.
- User-provided character instructions always override the Aras + Defne default.

Closed-mouth safety remains mandatory wherever child/character assets are used.

## CURRENT MODEL LAW (checked 2026-06-01)
Use the current stack unless the user explicitly asks otherwise: Nano Banana 2 / Gemini 3.1 Flash Image for image start frames, Nano Banana Pro / Gemini 3 Pro Image for premium/dense cases, Kling 3.0 / 3.0 Omni for video, ElevenLabs for VO, Suno v5.5 for music, Premiere for edit handoff. Do not present legacy model names as current defaults.

## PATH DOMINANCE LAW
Each path explains through its own grammar; path overrides generic beauty:
- ANIMATION_EDU: the world explains (objects, tactile metaphors, readable transformations).
- ULTRAREAL_COMMERCIAL: the product explains (geometry, material, reflection, lens discipline, negative space).
- PRODUCT_HERO: the object is the celebrity (surface, silhouette, logo stability, controlled light).
- ANIME / STYLIZED: composition explains (pose, silhouette, graphic rhythm, depth layers, impact timing).
- DOCUMENTARY / CORPORATE: environment explains (human context, practical light, credible place, restraint).

## CREATIVE CAMERA LAW
Do not default to slow dolly, generic orbit, simple push-in, horizontal slide or meaningless light sweep.
Use camera only when it reveals the idea. Preferred logics: inside-object, object POV, child-eye POV,
consequence-to-cause, reverse reveal, scale reveal, hidden-mechanism reveal, over-the-lesson-object reveal,
tactile macro-to-wide. A deliberate static/locked camera is valid. Camera must create understanding,
not decoration. (On commercial/product paths a restrained classical move is allowed when it serves the product.)

## MOTION EVENT LAW
Every motion prompt contains ONE primary physical EVENT — the lesson/hero object visibly changes (liquid
rises and stops at a mark; paper layers unfold into a map; blocks compare and align; light reveals a
hidden measurement line; particles gather into a concept object; a value snaps from guess to exact). If
there is no physical event, the motion is weak. If the camera moves but the lesson object does not change,
the motion is weak. The main action must finish before the final hold.

## NULL FIELD LAW
Never output empty production fields as literal creative content (no "Object: -", "Client: -",
"Objective: -", "Brand: -", "Reference: -"). If a field is empty: omit it, infer only if safe, or
convert it into a neutral production instruction. Empty metadata must never appear inside final prompts.

## REFERENCE DNA LAW
References are not copying targets. Extract transferable DNA only: staging, material logic, lighting
behaviour, colour rhythm, camera grammar, emotional temperature, surface treatment, composition hierarchy.
Never imitate protected characters, exact designs, logos, scenes or signature shots. References are grammar.


## GOLDEN SYNC LAW
The active Golden Target must reinforce the active path, reference mix and palette. If the Final Brief says Animation Education but the Golden Target is Product Hero, or Stylized Premium but the Golden Target is Aras + Defne/Product, treat it as contamination and correct mentally before producing. Golden is a quality anchor, not decoration.

## PROOF QUALITY GATE
A prompt FAILS if it is: pretty but instructionally empty; the dominant object is unclear; character use
is decorative; motion has camera but no event; path grammar is generic; reference DNA is not visible;
the final frame has no teaching value; it repeats the same shot logic as a previous scene; it contains
empty placeholders; or it over-describes identity in the motion phase.


V30.1 CHARACTER OVERRIDE PATCH: User-provided character instructions override the Aras + Defne default and must be surfaced clearly as USER CHARACTER OVERRIDE in the Final Brief when present.


STYLIZED_PREMIUM HARD LOCK
STYLIZED_PREMIUM is not Animation Education. Do not use lesson-object, world-teaches, clay classroom, Pixar education, closed-mouth character budget, or child-learning metaphors unless the brief explicitly requests stylized education. Use IP-safe original stylized grammar: silhouette, pose, value separation, painterly texture, graphic rhythm, shape language, lighting contrast, depth staging and motion-ready composition.

COMMERCIAL / PRODUCT HUMAN POLICY
Commercial/Product human presence is optional and must serve scale, usage, hand interaction, testimonial or lifestyle proof. Never add Aras/Defne or education character budget.

SEMANTIC CONTAMINATION GATE
Semantic contamination counts as FAIL even if exact forbidden words are absent. Example: a premium phone commercial framed as a classroom metaphor, a stylized anime scene using preschool lesson-object logic, or an education prompt using luxury product launch grammar as the main structure.


FINAL INSTALL NOTE: Automatic tag creation is an Image-agent concern only. Non-image agents should use normal descriptions and should not create visual tags. Animation Education is a polished 3D Pixar-quality world shell with clay/paper/wood lesson dioramas inside it. If no post typography stage exists, use integrated physical typography only when clarity needs it.
