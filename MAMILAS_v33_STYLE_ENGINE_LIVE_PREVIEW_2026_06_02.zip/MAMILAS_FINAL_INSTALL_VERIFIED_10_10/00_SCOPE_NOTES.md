Verified scope: Image owns visual tagging. Motion and Suno do not create tags. Site uses mamilas.html. World shell corrected: 3D Pixar-quality outer world with clay/paper/wood lesson diorama inside.
