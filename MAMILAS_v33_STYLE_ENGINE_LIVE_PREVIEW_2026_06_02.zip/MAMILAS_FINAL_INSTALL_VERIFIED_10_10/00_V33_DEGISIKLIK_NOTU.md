# MAMILAS v33 — Değişiklik Notu (2026-06-02)

Sadece 01_SITE/mamilas.html güncellendi. Ajan ve knowledge dosyaları aynı.
Kurulum yine 00_TURKCE_KOLAY_KURULUM.md ile aynı.

## Eklenen / düzeltilenler
1. Motion golden örnekleri gerçek 5-6s TEK olaya çekildi (morph kaynağı kapandı).
   Suno için eğitim + ürün golden eklendi; brief'e path'e göre enstrüman/bpm/yapı geldi.
2. Ingest artık ekran yazısını OTOMATIK çıkarıyor (zaman/ek/örnek/görev/başlık) ve
   fiziksel tipografi olarak görüntüye gömülmek üzere yazıyor (After Effects gerekmez).
   Doldurulmayan alanlar artık "-" olarak görünmüyor (silinmiş satır).
3. 3D Pixar dünya kabuğu + içeride clay/paper/wood diorama tüm eğitim dünyalarında net.
4. VISUAL STYLE ENGINE: Pixar -> Arcane / Spider-Verse / Ghibli / Anime / Claymation /
   Comic / Painterly tek tıkla değişir (Reference sayfası). Render lock, image ve motion
   prompt o stile döner, IP-safe kalır. "Auto" = seçili referanstan türetir.
5. Series DNA Lock (karakter/world/palet/stil/süre dondur), Batch ingest (=== ile çok script),
   Premiere CSV'ye on_screen_text sütunu, Görev sahnesi otomatik interaktif final kare.
6. Jilet brief + doktor->eczacı AGENT HANDSHAKE bloğu.
7. Canlı oyun-stili önizleme: tıkla, sağ paneldeki "sahne" anında değişir (stil dokuları).
8. 140 referansın hepsine bestPaths/bestPalettes eklendi (akıllı köprü) + 12 gerçek-dünya
   çekim setup'ı (lens+ışık+gramer) yeni "Real Setup" kategorisinde. Toplam 152 referans.
