Kurulum:
1) Site: 01_SITE/mamilas.html
2) GPT kullanacaksan 02_GPT_AGENT_INSTRUCTIONS içindeki 4 ajanı ayrı ayrı kur.
3) Claude kullanacaksan 03_CLAUDE_AGENT_INSTRUCTIONS içindeki 4 ajanı kur.
4) 04_SHARED_KNOWLEDGE_UPLOAD_TO_EACH_AGENT içindeki 9 knowledge dosyasını kullandığın her ajana Knowledge olarak yükle.
5) Knowledge dosyalarını instruction alanına yapıştırma.
