MAMILAS FINAL INSTALL VERIFIED. Open 00_TURKCE_KOLAY_KURULUM.md first. Use 01_SITE/mamilas.html. Install only IDEA / IMAGE / MOTION / SUNO. Upload the same 9 knowledge files from 04_SHARED_KNOWLEDGE_UPLOAD_TO_EACH_AGENT to each agent. Do not paste knowledge into instructions.


10/10 quality floor patch applied: Golden Target sync, path-aware preflight and 97+ internal output floor. See 00_10_10_UPGRADE_NOTES.md.

v31.3 Creative Director OS applied on 2026-06-01: current model registry, Kling 3.0 5-6s default splitting, Aras/Defne 25% budget scope, path-aware scene visuals, ElevenLabs/Suno/Premiere exports and simulation report.
