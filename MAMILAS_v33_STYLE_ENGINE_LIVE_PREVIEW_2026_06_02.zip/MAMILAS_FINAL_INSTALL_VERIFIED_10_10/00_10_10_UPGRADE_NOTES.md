# MAMILAS 10/10 Quality Floor Upgrade

Package derived from MAMILAS_FINAL_INSTALL_VERIFIED.zip without Lite conversion and without shortening GPT agent brains.

Surgical fixes applied:
- Final Brief Golden Target now synchronizes with active Production Path, reference mix and palette.
- Animation Education no longer falls back to Product Hero golden.
- Added missing IMAGE golden anchors for Stylized Premium and Documentary/Civic paths.
- Path integrity now syncs Golden Target during enforce/buildBrief.
- Preflight now catches golden contamination across Education, Stylized and Real paths.
- Knowledge rubric raised from 95+ to 97+ internal output floor.
- Production Laws now include Golden Sync Law.

Unchanged decisions:
- 4 install agents only: IDEA, IMAGE, MOTION, SUNO.
- Same 8 shared knowledge files are uploaded to every agent as Knowledge, not pasted into instructions.
- No Lite mode. No agent brain shortening.
- Clay/paper/wood/fabric/lightbox remain lesson diorama / teaching prop systems inside the 3D Pixar-quality education world, not the outside world.
- Automatic @tag creation remains Image-only and only for @aras / @defne in the Aras + Defne Education preset.
- Motion creates no new tags and no new text. Suno has no @tag / start-frame / image-only logic.
